<?php

// require ('../app/functions.php');
// require ('../app/validate.php');

$csvFile = filter_input(INPUT_POST, "名前", "年齢", "性別", FILTER_SANITIZE_SPECIAL_CHARS);

$pdo = new PDO('mysql:host=localhost:8889;dbname=myapp;charset=utf8','root','root');

$stmt = $db->prepare('INSERT INTO phpcsv ("名前", "年齢", "性別") VALUES(?)(?)(?)');
if (!$db->error):
  die($db->error);
endif;

$stmt->bind_param($csvFile);
$ret = $stmt->execute();

if ($ret):
  echo '登録されました。';
else:
  echo $db->error;
endif;

include ('../app/_parts/_header.php');

?>

